import express from "express";
import cors from "cors";
import fetch from "node-fetch";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Define your CORS whitelist
const whitelist = ['http://localhost:3000', 'http://127.0.0.1:5500', 'https://cricketstoreonline.com', 'https://szf6kwy2dls7x8nw-62411112615.shopifypreview.com'];

const corsOptions = {
  origin: (origin, callback) => {
    if (whitelist.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
      console.log("Not allowed by CORS: ", origin);
    }
  },
  credentials: true,
};
app.use(cors(corsOptions));

const SHOPIFY_API_URL =
  "https://cricketstoreonline.myshopify.com/admin/api/2025-01/graphql.json";
const ACCESS_TOKEN = "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";

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

// Serve the HTML page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// Route to get all locations
app.get("/locations", async (req, res) => {
  const query = `
    query {
      locations(first: 50) {
        edges {
          node { id name }
        }
      }
    }
  `;
  try {
    const response = await fetch(SHOPIFY_API_URL, {
      method: "POST",
      headers: {
        "X-Shopify-Access-Token": ACCESS_TOKEN,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ query }),
    });
    const data = await response.json();
    
    if (data.errors) {
      console.error("GraphQL Errors:", data.errors);
      return res.status(500).json({ error: "Failed to fetch locations" });
    }
    
    const locations = data.data.locations.edges.map((edge) => edge.node);
    res.json({ locations });
  } catch (error) {
    console.error("Error fetching locations:", error);
    res.status(500).json({ error: "Failed to fetch locations" });
  }
});

// GraphQL proxy endpoint
app.post("/graphql", async (req, res) => {
  try {
    const { query, variables } = req.body;
    
    const response = await fetch(SHOPIFY_API_URL, {
      method: "POST",
      headers: {
        "X-Shopify-Access-Token": ACCESS_TOKEN,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ query, variables }),
    });
    
    const data = await response.json();
    res.json(data);
  } catch (error) {
    console.error("Error in GraphQL proxy:", error);
    res.status(500).json({ error: "Failed to process GraphQL request" });
  }
});

// Start server on port 3000
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});